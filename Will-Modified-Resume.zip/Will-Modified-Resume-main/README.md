My personal LaTeX template using Awesome CV template 

https://www.overleaf.com/read/dmpwdjzqddwd

Improvements: Added hyperlink footer, bulleted columns, text styling, code documentation, etc,...

Source:

https://github.com/posquit0/Awesome-CV

https://www.overleaf.com/latex/templates/awesome-cv/dfnvtnhzhhbm


Instruction:

1. Download [Will_Modified_Resume.zip](https://github.com/willb256/Will-Modified-Resume/blob/main/Will_Modified_Resume.zip) file. Don't unzip unless you want to use a different environment. 

2. Open https://www.overleaf.com/project. Login or register for a free account if you have not done so. 

3. Press New Project on the top left

4. Press Upload Project

5. Select the Will_Modified_Resume.zip file. Once uploaded, the template will not compile yet.

6. Press the menu button on the top left

7. Change the compiler to XeLaTeX

8. Press recompile on the right side


Disclaimer: The person in this resume is not me. But rather, the original creator of Awesome CV. Some content has also been modified.
![resume v11](https://user-images.githubusercontent.com/59489624/183143158-5b55b13b-9d4d-4eaf-8103-581957bd89eb.png)
![resume v12](https://user-images.githubusercontent.com/59489624/183143163-aaa80a1f-3c5c-4881-a43a-afe433a45335.png)
